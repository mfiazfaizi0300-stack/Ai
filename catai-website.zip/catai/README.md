# 🐱 cat.ai

A real AI chat website powered by Claude. Deploy it live in under 5 minutes for free.

---

## 🚀 Deploy to Vercel (Free — Live URL in 5 mins)

### Step 1 — Get a free Anthropic API key
1. Go to **https://console.anthropic.com**
2. Sign up for a free account
3. Click **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)

### Step 2 — Upload this project to GitHub
1. Go to **https://github.com/new** and create a new repository (name it `cat-ai`)
2. Upload all these files into it (drag & drop works)

### Step 3 — Deploy on Vercel
1. Go to **https://vercel.com** and sign in with GitHub
2. Click **"Add New Project"** → import your `cat-ai` repo
3. Before deploying, click **"Environment Variables"** and add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your API key from Step 1
4. Click **Deploy** 🚀

### Step 4 — Get your live URL
Vercel gives you a free URL like:
**`https://cat-ai-yourname.vercel.app`**

You can also connect a custom domain like `cat.ai` from the Vercel dashboard.

---

## 💻 Run locally

```bash
npm install
ANTHROPIC_API_KEY=sk-ant-your-key npm run dev
```

Then open http://localhost:3000

---

## 📁 File structure

```
cat-ai/
├── pages/
│   ├── index.js        ← Main chat UI
│   ├── _app.js         ← App wrapper
│   └── api/
│       └── chat.js     ← Backend API (hides your API key)
├── styles/
│   └── globals.css     ← Global styles
└── package.json
```
