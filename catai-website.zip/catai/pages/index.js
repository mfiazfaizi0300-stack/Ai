import { useState, useRef, useEffect } from 'react';
import Head from 'next/head';

const SUGGESTIONS = [
  { icon: '✍️', label: 'Write a story', sub: 'Creative writing', prompt: 'Write a short funny story about a cat who discovers the internet' },
  { icon: '🧠', label: 'Explain AI', sub: 'In plain English', prompt: 'Explain how neural networks work in simple terms' },
  { icon: '💻', label: 'Write code', sub: 'Any language', prompt: 'Write a Python function to find all prime numbers up to n' },
  { icon: '🐾', label: 'Cat facts', sub: 'Fun & random', prompt: 'What are 5 unusual and surprising facts about cats?' },
];

const QUICK_ITEMS = [
  { label: 'Python web scraper', prompt: 'Write a Python script to scrape a website with requests and BeautifulSoup' },
  { label: 'Black holes explained', prompt: 'Explain black holes in simple, interesting terms' },
  { label: 'Startup ideas 2025', prompt: 'Give me 5 creative startup ideas for 2025' },
  { label: 'Internet haiku', prompt: 'Write a beautiful haiku about the internet' },
  { label: 'Productivity tips', prompt: 'What are the best science-backed productivity tips?' },
  { label: 'Debug my code', prompt: 'Help me debug my code — I\'ll paste it below:' },
];

function TypingDots() {
  return (
    <div style={{ display: 'flex', gap: 5, alignItems: 'center', padding: '4px 0' }}>
      {[0, 1, 2].map(i => (
        <span key={i} style={{
          display: 'inline-block',
          width: 7, height: 7,
          borderRadius: '50%',
          background: '#555',
          animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite`,
        }} />
      ))}
    </div>
  );
}

function escHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function formatAI(text) {
  // code blocks
  text = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    const label = lang || 'code';
    return `<div style="margin:12px 0;border-radius:10px;overflow:hidden;border:1px solid #2a2a2a">
      <div style="background:#111;padding:8px 14px;font-size:0.68rem;color:#555;letter-spacing:0.05em;text-transform:uppercase;font-family:monospace">${label}</div>
      <pre style="background:#0a0a0a;padding:16px;overflow-x:auto;font-size:0.8em;line-height:1.65;font-family:'Courier New',monospace;margin:0"><code>${escHtml(code.trim())}</code></pre>
    </div>`;
  });
  // inline code
  text = text.replace(/`([^`\n]+)`/g, '<code style="background:rgba(255,255,255,0.07);padding:2px 7px;border-radius:5px;font-size:0.83em;font-family:\'Courier New\',monospace">$1</code>');
  // bold
  text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // newlines
  text = text.replace(/\n/g, '<br/>');
  return text;
}

export default function Home() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  function autoResize() {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 180) + 'px';
  }

  function fillInput(text) {
    setInput(text);
    setTimeout(() => {
      textareaRef.current?.focus();
      autoResize();
    }, 30);
  }

  function newChat() {
    setMessages([]);
    setHistory([]);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = '26px';
  }

  async function send() {
    const text = input.trim();
    if (!text || busy) return;

    setBusy(true);
    setInput('');
    setTimeout(() => {
      if (textareaRef.current) textareaRef.current.style.height = '26px';
    }, 10);

    const newHistory = [...history, { role: 'user', content: text }];
    setHistory(newHistory);
    setMessages(prev => [...prev, { role: 'user', content: text }, { role: 'typing' }]);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newHistory }),
      });
      const data = await res.json();
      const reply = data?.content?.[0]?.text || "Hmm, I couldn't generate a response. Try again! 🐾";
      setHistory(h => [...h, { role: 'assistant', content: reply }]);
      setMessages(prev => [...prev.filter(m => m.role !== 'typing'), { role: 'ai', content: reply }]);
    } catch {
      setMessages(prev => [...prev.filter(m => m.role !== 'typing'), { role: 'ai', content: 'Connection error. Please try again.' }]);
    }

    setBusy(false);
    textareaRef.current?.focus();
  }

  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  const isEmpty = messages.length === 0;

  return (
    <>
      <Head>
        <title>cat.ai — Your intelligent companion</title>
        <meta name="description" content="cat.ai — A brilliant AI assistant with feline curiosity. Ask anything." />
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🐱</text></svg>" />
      </Head>

      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#0d0d0d' }}>

        {/* TOPBAR */}
        <header style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '13px 20px',
          borderBottom: '1px solid #1e1e1e',
          flexShrink: 0,
          background: '#0d0d0d',
          zIndex: 10,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button
              onClick={() => setSidebarOpen(o => !o)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#444', fontSize: 18, lineHeight: 1, padding: '2px 4px', display: 'flex', alignItems: 'center' }}
              title="Toggle sidebar"
            >
              ☰
            </button>
            <div style={{ width: 32, height: 32, background: '#ff6b2b', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17 }}>🐱</div>
            <span style={{ fontWeight: 700, fontSize: '1rem', letterSpacing: '-0.02em' }}>cat.ai</span>
          </div>

          {/* URL pill */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 7,
            background: '#111', border: '1px solid #222', borderRadius: 20,
            padding: '5px 14px', fontSize: '0.71rem', color: '#555',
            fontFamily: 'monospace',
          }}>
            <span style={{ width: 7, height: 7, background: '#22c55e', borderRadius: '50%', display: 'inline-block' }} />
            https://cat.ai
          </div>

          <button
            onClick={newChat}
            style={{
              background: '#161616', border: '1px solid #242424', color: '#ccc',
              padding: '7px 15px', borderRadius: 8, fontSize: '0.77rem',
              fontWeight: 500, cursor: 'pointer', fontFamily: 'Inter, sans-serif',
              transition: 'border-color 0.2s',
            }}
            onMouseEnter={e => e.currentTarget.style.borderColor = '#ff6b2b'}
            onMouseLeave={e => e.currentTarget.style.borderColor = '#242424'}
          >
            + New chat
          </button>
        </header>

        {/* BODY */}
        <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

          {/* SIDEBAR */}
          <aside style={{
            width: sidebarOpen ? 220 : 0,
            borderRight: sidebarOpen ? '1px solid #1e1e1e' : 'none',
            flexShrink: 0,
            overflow: 'hidden',
            transition: 'width 0.25s ease',
            display: 'flex',
            flexDirection: 'column',
          }}>
            <div style={{ padding: '16px 10px', minWidth: 220 }}>
              <div style={{ fontSize: '0.63rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#333', padding: '4px 8px 10px' }}>
                Quick prompts
              </div>
              {QUICK_ITEMS.map((item, i) => (
                <SidebarItem key={i} label={item.label} onClick={() => fillInput(item.prompt)} />
              ))}
            </div>
          </aside>

          {/* CHAT AREA */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>

            {/* MESSAGES */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '24px 0 16px' }}>
              {isEmpty ? (
                <EmptyState onSuggest={fillInput} />
              ) : (
                <div style={{ maxWidth: 780, margin: '0 auto', padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {messages.map((msg, i) => (
                    <MessageRow key={i} msg={msg} />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>

            {/* INPUT */}
            <div style={{ borderTop: '1px solid #1e1e1e', padding: '14px 20px 20px', flexShrink: 0, background: '#0d0d0d' }}>
              <div style={{
                maxWidth: 780, margin: '0 auto',
                background: '#141414',
                border: '1px solid #242424',
                borderRadius: 14,
                display: 'flex', alignItems: 'flex-end', gap: 8,
                padding: '10px 12px',
                transition: 'border-color 0.2s',
              }}
                onFocus={e => e.currentTarget.style.borderColor = '#ff6b2b'}
                onBlur={e => e.currentTarget.style.borderColor = '#242424'}
              >
                <textarea
                  ref={textareaRef}
                  value={input}
                  onChange={e => { setInput(e.target.value); autoResize(); }}
                  onKeyDown={handleKey}
                  placeholder="Message cat.ai..."
                  rows={1}
                  style={{
                    flex: 1, background: 'none', border: 'none', outline: 'none',
                    color: '#f0f0f0', fontSize: '0.9rem', lineHeight: 1.65,
                    resize: 'none', maxHeight: 180, minHeight: 26,
                    padding: '2px 0', caretColor: '#ff6b2b',
                    fontFamily: 'Inter, sans-serif',
                  }}
                />
                <button
                  onClick={send}
                  disabled={busy || !input.trim()}
                  style={{
                    width: 36, height: 36,
                    background: (busy || !input.trim()) ? '#1e1e1e' : '#ff6b2b',
                    border: '1px solid ' + ((busy || !input.trim()) ? '#2a2a2a' : '#ff6b2b'),
                    borderRadius: 9,
                    cursor: (busy || !input.trim()) ? 'not-allowed' : 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0,
                    transition: 'background 0.2s',
                    color: 'white',
                  }}
                >
                  {busy ? (
                    <span style={{ fontSize: 14 }}>⏳</span>
                  ) : (
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="22" y1="2" x2="11" y2="13" />
                      <polygon points="22 2 15 22 11 13 2 9 22 2" />
                    </svg>
                  )}
                </button>
              </div>
              <p style={{ maxWidth: 780, margin: '8px auto 0', fontSize: '0.66rem', color: '#333', textAlign: 'center' }}>
                Enter to send · Shift+Enter for new line · cat.ai can make mistakes
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function SidebarItem({ label, onClick }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        padding: '8px 10px', borderRadius: 7,
        fontSize: '0.78rem',
        color: hovered ? '#f0f0f0' : '#555',
        background: hovered ? '#1a1a1a' : 'transparent',
        cursor: 'pointer',
        transition: 'all 0.15s',
        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
      }}
    >
      {label}
    </div>
  );
}

function EmptyState({ onSuggest }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: '100%', gap: 14,
      textAlign: 'center', padding: 40,
      animation: 'fadeIn 0.4s ease',
    }}>
      <div style={{ fontSize: 60, animation: 'float 3s ease-in-out infinite' }}>🐱</div>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.03em', color: '#f0f0f0' }}>
        What&apos;s on your mind?
      </h1>
      <p style={{ fontSize: '0.82rem', color: '#555', maxWidth: 300, lineHeight: 1.75 }}>
        I&apos;m cat.ai — ask me anything. Code, writing, math, ideas, explanations.
      </p>
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr',
        gap: 8, marginTop: 10, maxWidth: 500, width: '100%',
      }}>
        {SUGGESTIONS.map((s, i) => (
          <SuggestionCard key={i} s={s} onSuggest={onSuggest} />
        ))}
      </div>
    </div>
  );
}

function SuggestionCard({ s, onSuggest }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={() => onSuggest(s.prompt)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? 'rgba(255,107,43,0.08)' : '#111',
        border: `1px solid ${hovered ? '#ff6b2b' : '#1e1e1e'}`,
        borderRadius: 10, padding: '14px 16px',
        fontSize: '0.79rem', cursor: 'pointer', textAlign: 'left',
        transition: 'all 0.18s',
      }}
    >
      <div style={{ fontSize: '1.2rem', marginBottom: 6 }}>{s.icon}</div>
      <div style={{ fontWeight: 600, color: '#e0e0e0' }}>{s.label}</div>
      <div style={{ color: '#444', fontSize: '0.71rem', marginTop: 3 }}>{s.sub}</div>
    </div>
  );
}

function MessageRow({ msg }) {
  const isUser = msg.role === 'user';
  const isTyping = msg.role === 'typing';

  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      alignItems: isUser ? 'flex-end' : 'flex-start',
      gap: 5, padding: '5px 0',
      animation: 'msgIn 0.22s ease',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 7,
        fontSize: '0.68rem', color: '#444', fontWeight: 500,
        flexDirection: isUser ? 'row-reverse' : 'row',
      }}>
        <div style={{
          width: 22, height: 22, borderRadius: 6,
          background: isUser ? '#2a2a2a' : '#ff6b2b',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12,
        }}>
          {isUser ? '👤' : '🐱'}
        </div>
        <span>{isUser ? 'You' : 'cat.ai'}</span>
      </div>

      {/* Bubble */}
      <div style={{
        maxWidth: '82%',
        padding: isTyping ? '12px 16px' : '12px 16px',
        borderRadius: isUser ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
        fontSize: '0.89rem', lineHeight: 1.75,
        wordBreak: 'break-word',
        background: isUser ? '#ff6b2b' : '#141414',
        border: isUser ? 'none' : '1px solid #202020',
        color: '#f0f0f0',
      }}>
        {isTyping ? (
          <TypingDots />
        ) : isUser ? (
          <span style={{ whiteSpace: 'pre-wrap' }}>{msg.content}</span>
        ) : (
          <div dangerouslySetInnerHTML={{ __html: formatAI(msg.content) }} />
        )}
      </div>
    </div>
  );
}
